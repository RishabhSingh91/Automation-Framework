/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation.getpageobjects;

/**
 *
 * @author prashantshukla
 */
public enum Tiers {
    PROD, prod, production, PRODUCTION, Production,
    Staging, STG, stg;
}
